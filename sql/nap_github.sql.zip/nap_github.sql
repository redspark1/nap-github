-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 31, 2017 at 05:05 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nap_github`
--

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1503379396),
('m130524_201442_init', 1503379404);

-- --------------------------------------------------------

--
-- Table structure for table `service_categories`
--

CREATE TABLE `service_categories` (
  `service_category_id` int(11) NOT NULL,
  `service_category_name` varchar(255) NOT NULL,
  `service_category_description` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `service_categories`
--

INSERT INTO `service_categories` (`service_category_id`, `service_category_name`, `service_category_description`) VALUES
(1, 'Service Category Name 1', 'Service Category Name 1'),
(2, 'A Service Category', 'A Service Category');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `first_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `profile_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_street_address_1` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address_street_address_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_street_address_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address_suburb` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address_state` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address_postcode` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address_country` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mobile_no` varchar(24) COLLATE utf8_unicode_ci NOT NULL,
  `emergency_contact_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `emergency_contact_phone_number` varchar(24) COLLATE utf8_unicode_ci NOT NULL,
  `level_of_professional_qualification` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `accreditation_id` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level_of_professional_qualification_text` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `level_of_educational_qualification` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `level_of_educational_qualification_text` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_professional_experience` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `current_restrictions_on_registration_or_accreditation` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `restriction_reason` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `current_clearance_for_working_with_children` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `current_criminal_check` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `proficiency_in_english` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `work_right_in_country` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `specialization_and_recently_of_practice` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `recency_of_practice_month` tinyint(2) DEFAULT NULL,
  `recency_of_practice_year` tinyint(2) DEFAULT NULL,
  `abn_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `b_s_b` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `account_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `account_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `role` varchar(24) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'sysadmin admin user provider',
  `last_login` timestamp NULL DEFAULT NULL,
  `enterprise_id` int(11) DEFAULT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `first_name`, `last_name`, `profile_image`, `address_street_address_1`, `address_street_address_2`, `address_street_address_3`, `address_suburb`, `address_state`, `address_postcode`, `address_country`, `mobile_no`, `emergency_contact_name`, `emergency_contact_phone_number`, `level_of_professional_qualification`, `accreditation_id`, `level_of_professional_qualification_text`, `level_of_educational_qualification`, `level_of_educational_qualification_text`, `total_professional_experience`, `current_restrictions_on_registration_or_accreditation`, `restriction_reason`, `current_clearance_for_working_with_children`, `current_criminal_check`, `proficiency_in_english`, `work_right_in_country`, `specialization_and_recently_of_practice`, `recency_of_practice_month`, `recency_of_practice_year`, `abn_number`, `b_s_b`, `account_number`, `account_name`, `role`, `last_login`, `enterprise_id`, `created_at`, `updated_at`, `created_by`, `updated_by`) VALUES
(1, 'admin', 'i9hjE0fnZHIDv9q2iZYc__bh-d-8_eW7', '$2y$13$QL7eU8xHGOq8vlylHxPIo.CQCGLvmeg5HWwaLADiVrTT6FPPNyLZ6', NULL, 'prakash@redsparkinfo.com', 10, 'Prakash', 'Chand', 'Koala-1504088640-23302.jpg', '', NULL, NULL, '', '', '', '', '', '', '', '', NULL, NULL, '', NULL, '', '', NULL, '', '', '', '', NULL, NULL, NULL, '', '', '', '', 'sysadmin', NULL, NULL, 1503401569, 1504088640, 0, 0),
(2, 'testing049', '', '', NULL, 'testing049.test@gmail.com', 10, 'Testing049', 'Test', '', 'Redspark', '', '', 'Vadodara', 'Gujarat', '390001', 'India', '(02) 2345 6789', 'Prakash', '01234567890', 'MCA', 'AADDF3434', 'AADDF3434', 'AADDF3434', 'AADDF3434', 'AADDF3434', 'No', 'AADDF3434', 'No', 'No', 'Conversational Proficiency None', 'No', 'AADDF3434', NULL, NULL, 'AADDF3434', 'AADDF3434', 'AADDF3434', 'AADDF3434', 'admin', NULL, 2, 1503577588, 1503577588, 0, 0),
(4, 'helen', '', '', NULL, 'HelenCHarris@jourrapide.com', 10, 'Helen C. ', 'Harris', 'Penguins-1504095202-28097.jpg', '23', 'Martens Place', '', 'KAMERUNGA', 'QLD', '4870', 'Australia', '(07) 4099 3553', 'Maria V. Huckabee', '(02) 4652 6110', 'Graduate', '0e949898', '5', '5', '5', '5', 'No', '', 'No', 'No', 'No', 'No', 'None', NULL, NULL, '4f20a88d2f5c', '8de3', '5410 0561 4843 8950', 'Luke M. George', 'user', NULL, 2, NULL, NULL, NULL, NULL),
(5, 'luke', '', '', NULL, 'LukeMGeorge@teleworm.us', 10, 'Luke M. ', 'George', '', '57', 'Florabunda Lane', '', 'GLENQUARIE', 'NSW', '2564', 'Australia', '(02) 4015 2280', '2564', '0353037675', 'Accountancy and Finance', '4687a79a', '', 'Graduate', '', '5', 'No', '', 'No', 'No', 'Conversational Proficiency None', 'No', 'specialization 1', 2, 2, '2436', '9d58', '4532 0891 2121 4839', '4532 0891 2121 4839', 'provider', NULL, 2, NULL, NULL, NULL, NULL),
(6, 'kari', '', '', NULL, 'KariCHeffington@armyspy.com', 0, 'Kari C.', 'Heffington', '', '46', 'Chapman Avenue', '', 'BUMBALDRY', 'NSW', '2794', 'Australia', '(02) 4015 2280', 'Maryanne K. Evans', 'Maryanne K. Evans', 'Graduate', '', '', '5', '', '5', 'No', '', 'No', 'No', 'Conversational Proficiency None', 'No', '', NULL, NULL, 'cd655cc3cf78', 'b130', '4929 8858 9272 2319', 'Maryanne K. Evans', 'provider', NULL, 2, NULL, NULL, NULL, NULL),
(7, 'provider', 'i9hjE0fnZHIDv9q2iZYc__bh-d-8_eW7', '$2y$13$QL7eU8xHGOq8vlylHxPIo.CQCGLvmeg5HWwaLADiVrTT6FPPNyLZ6', NULL, 'prakash.redspark@gmail.com', 10, '', '', NULL, '', NULL, NULL, '', '', '', '', '', '', '', '', NULL, NULL, '', NULL, '', '', NULL, '', '', '', '', NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, 1504014264, 1504014264, NULL, NULL),
(9, '', 'd9j49uZIxAe3q-lQyM1eXpjuGRA7wbts', '$2y$13$90glnx5l1GqWD5x8aLVgIuUELMbYxrOd9aArYfnYdpzG5SBlm4Wxu', NULL, 'testing051.test@gmail.com', 10, '', '', NULL, '', NULL, NULL, '', '', '', '', '', '', '', '', NULL, NULL, '', NULL, '', '', NULL, '', '', '', '', NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, 1504072096, 1504072096, NULL, NULL),
(10, NULL, 'gpqZKHl53XXHEaDyQYfCOUNsub8IDKn9', '$2y$13$xTqFP0UCVQjr6aFLSfVTkOr4A/JuTPRN3J9OVznUUqWRlcXRo1Mzu', NULL, 'testing050.test@gmail.com', 10, '', '', NULL, '', NULL, NULL, '', '', '', '', '', '', '', '', NULL, NULL, '', NULL, '', '', NULL, '', '', '', '', NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, 1504072164, 1504072164, NULL, NULL),
(11, NULL, 'GqHuYiWQNVXoE3LBMgqvVqUwJf-wld_T', '$2y$13$/irXZzoxEJa/ziYiBErLi.W1L0iaEkk7z0MTINoIqsgUAkG3HGgv6', NULL, 'testing018.test@gmail.com', 10, '', '', NULL, '', NULL, NULL, '', '', '', '', '', '', '', '', NULL, NULL, '', NULL, '', '', NULL, '', '', '', '', NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, 1504072477, 1504072477, NULL, NULL),
(12, NULL, 'n34aXgHWGmITrBXrKELHlYotw04ZsWlq', '$2y$13$8uH0Scs.vtFml/VPSqUc7O62unLZqxpEH6vexGv9dlFDYn74/.rnC', NULL, 'testing058.test@gmail.com', 10, '', '', NULL, '', NULL, NULL, '', '', '', '', '', '', '', '', NULL, NULL, '', NULL, '', '', NULL, '', '', '', '', NULL, NULL, NULL, '', '', '', '', NULL, NULL, NULL, 1504072795, 1504072795, NULL, NULL),
(13, NULL, '', '', NULL, 'ReneDSuter@teleworm.us', 10, 'Rene D. ', 'Suter', NULL, '69', 'Oak Street', '', 'GULMARRAD', 'NSW ', '2463', 'Australia', '(03) 6797 7772', 'Christian D. Davis', '(08) 8744 0285', 'Accountancy and Finance', '4680', '', 'Graduate', '', '5', 'No', '', 'No', 'No', 'Conversational Proficiency None', 'No', 'specialization 1', NULL, NULL, '1ff539e2c580', '4b76', '5396 8808 2514 3387', 'Christian D. Davis', 'provider', NULL, NULL, NULL, NULL, NULL, NULL),
(14, NULL, '', '', NULL, 'testing0491.test@gmail.com', 10, 'Testing0491', 'Test1', 'Koala-1504094421-5906.jpg', 'Redspark', '', '', 'Vadodara', 'Gujarat', '390001', 'India', '01234567891', '', '', '', NULL, NULL, '', NULL, '', '', NULL, '', '', '', '', NULL, NULL, NULL, '', '', '', '', 'user', NULL, 2, NULL, NULL, NULL, NULL),
(15, NULL, '', '', NULL, 'testing0492.test@gmail.com', 0, 'Testing0492', 'Test2', 'Jellyfish-1504095627-16194.jpg', 'Redspark2', '', '', 'Vadodara2', 'Gujarat2', '3900012', 'India2', '01234567892', '', '', '', NULL, NULL, '', NULL, '', '', NULL, '', '', '', '', NULL, NULL, NULL, '', '', '', '', 'user', NULL, 3, NULL, NULL, NULL, NULL),
(16, NULL, '', '', NULL, 'EsterJMartin@dayrep.com', 10, 'Ester J. ', 'Martin', 'Desert-1504095715-26934.jpg', '64 ', 'Mildura Street', '', 'COLES BAY ', 'TAS', '7215', 'Australia', '(03) 6266 0970', '', '', '', NULL, NULL, '', NULL, '', '', NULL, '', '', '', '', NULL, NULL, NULL, '', '', '', '', 'admin', NULL, 3, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `service_categories`
--
ALTER TABLE `service_categories`
  ADD PRIMARY KEY (`service_category_id`),
  ADD UNIQUE KEY `service_category_name` (`service_category_name`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `password_reset_token` (`password_reset_token`),
  ADD KEY `enterprise_id` (`enterprise_id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `service_categories`
--
ALTER TABLE `service_categories`
  MODIFY `service_category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
